export class CellTemplateModel {
    constructor() {
        this.iconCellTemplate = "icon";
        this.legendCellTemplate = "legend";
        this.linkCellTemplate = "link";
        this.checkboxCellTemplate = "checkbox";
    }
}